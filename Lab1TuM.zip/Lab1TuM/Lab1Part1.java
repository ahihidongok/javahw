/**
 * CSE1310-005 Lab 1 Part 1
 */
package lab1part1;

/**
 * Tu Mai
 * UTA ID 1001594173
 * @author Mai Tu
 */
public class Lab1Part1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
       // First program to try out the NetBeans IDE
        
        
        System.out.println("Testing arithmetic and output");
        System.out.println("14");
        System.out.println("32");
        System.out.println("32-14");
        System.out.println(32-14);
        
        System.out.println("Testing more arithmetic and output");
        System.out.println("14 * 32 = ");
        System.out.println(14*32);
        System.out.print("14.0 * 32.0 = ");
        System.out.println(14.0 * 32.0); 
        System.out.print("14 * 32 =");
        System.out.print(14 * 32);
        System.out.println(14.0*32.0);
        System.out.println("");
        
        System.out.println("14 * 32 = " + (14 * 32) + " or " + (14.0*32.0));
        
         
      
        
        
        
 
        
    }
    
}
